/**
 * B站活动筛选助手 - Content Script
 * 注入B站活动列表页面，提供筛选、排序、搜索、卡片增强功能
 */

(function () {
  'use strict';

  // ========== 状态 ==========
  let activities = [];
  let settings = {
    videoType: '',
    filters: {
      category: 'all',
      time: 'all',
      reward: 'all',
      difficulty: 'all',
      search: '',
      sort: 'days-asc'
    }
  };

  // ========== 工具函数（来自 BAFCore 三端共享，见根目录 core.js） ==========
  const { esc, debounce, daysLeft, formatDate, calcMatch, getMatchLevel, getCategoryIcon, fetchRawActivities, browserFetchOne, transformActivities } = BAFCore;

  // ========== 数据加载 ==========
  async function loadData() {
    try {
      // 从background获取设置
      const settingsResp = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
      if (settingsResp.success && settingsResp.settings) {
        settings = { ...settings, ...settingsResp.settings };
        if (!settings.filters) settings.filters = {};
      }

      // 从background获取活动数据
      const resp = await chrome.runtime.sendMessage({ type: 'FETCH_ACTIVITIES' });
      if (resp.success) {
        activities = resp.data;
        if (resp.stale) console.warn('[B站活动筛选助手] 使用的是过期缓存数据');
        return true;
      }
      throw new Error(resp.error || '获取失败');
    } catch (err) {
      console.error('[B站活动筛选助手] 数据加载失败:', err);
      // fallback: 直接在页面上下文调用API（core.js 本地转换，与正常路径推断一致）
      try {
        activities = await fetchInPage();
        return true;
      } catch (e) {
        console.error('[B站活动筛选助手] fallback也失败:', e);
        return false;
      }
    }
  }

  // fallback: 在页面上下文中直接调用B站API并用 BAFCore 转换
  async function fetchInPage() {
    const items = await fetchRawActivities(browserFetchOne);
    return transformActivities(items);
  }

  // ========== 筛选逻辑 ==========
  function filterActivities() {
    let list = [...activities];
    const f = settings.filters;

    if (f.category !== 'all') {
      list = list.filter(a => (a.categories || [a.category]).includes(f.category));
    }

    if (f.time !== 'all') {
      list = list.filter(a => {
        const days = daysLeft(a.endDate);
        if (f.time === 'week') return days >= 0 && days <= 7;
        if (f.time === 'month') return days >= 0 && days <= 30;
        if (f.time === 'long') return days > 30;
        return true;
      });
    }

    if (f.reward !== 'all') {
      list = list.filter(a => a.rewardType === f.reward);
    }

    if (f.difficulty !== 'all') {
      list = list.filter(a => a.difficulty === f.difficulty);
    }

    if (f.search) {
      const kw = f.search.toLowerCase();
      list = list.filter(a =>
        a.title.toLowerCase().includes(kw) ||
        a.tags.some(t => t.toLowerCase().includes(kw)) ||
        a.desc.toLowerCase().includes(kw)
      );
    }

    list = list.filter(a => daysLeft(a.endDate) >= -1);

    // 排序
    if (f.sort === 'days-asc') {
      list.sort((a, b) => daysLeft(a.endDate) - daysLeft(b.endDate));
    } else if (f.sort === 'days-desc') {
      list.sort((a, b) => daysLeft(b.endDate) - daysLeft(a.endDate));
    } else if (f.sort === 'match-desc') {
      list.sort((a, b) => (calcMatch(b, settings.videoType) || 0) - (calcMatch(a, settings.videoType) || 0));
    }

    return list;
  }

  // ========== 渲染 ==========
  function renderToolbar() {
    // 避免重复注入
    if (document.getElementById('baf-toolbar')) return;

    const toolbar = document.createElement('div');
    toolbar.id = 'baf-toolbar';
    toolbar.className = 'bili-activity-filter-toolbar';

    const categories = getAllCategories();

    toolbar.innerHTML = `
      <div class="baf-header">
        <div class="baf-title"><img src="${chrome.runtime.getURL('icons/icon48.png')}" class="baf-title-logo" alt="logo"> B站活动筛选助手</div>
        <div class="baf-stats">
          共 <strong id="baf-total">0</strong> 个活动 |
          进行中 <strong id="baf-active">0</strong> |
          本周截止 <strong id="baf-ending">0</strong> |
          筛选结果 <strong id="baf-result">0</strong>
        </div>
      </div>
      <div class="baf-filter-row">
        <span class="baf-filter-label">分类</span>
        <div class="baf-filter-btns" id="baf-cat-btns">
          <span class="baf-filter-btn active" data-cat="all">全部</span>
          ${categories.map(c => `<span class="baf-filter-btn" data-cat="${c}">${c}</span>`).join('')}
        </div>
      </div>
      <div class="baf-filter-row">
        <span class="baf-filter-label">时间</span>
        <div class="baf-filter-btns" id="baf-time-btns">
          <span class="baf-filter-btn active" data-time="all">全部</span>
          <span class="baf-filter-btn" data-time="week">本周截止</span>
          <span class="baf-filter-btn" data-time="month">本月截止</span>
          <span class="baf-filter-btn" data-time="long">长期</span>
        </div>
        <span class="baf-filter-label" style="margin-left:16px;">奖励</span>
        <div class="baf-filter-btns" id="baf-reward-btns">
          <span class="baf-filter-btn active" data-reward="all">全部</span>
          <span class="baf-filter-btn" data-reward="现金瓜分">现金瓜分</span>
          <span class="baf-filter-btn" data-reward="固定奖金">固定奖金</span>
          <span class="baf-filter-btn" data-reward="流量扶持">流量扶持</span>
        </div>
      </div>
      <div class="baf-search-row">
        <input type="text" class="baf-search-input" id="baf-search" placeholder="搜索活动名称、标签..." />
        <input type="text" class="baf-video-type-input" id="baf-video-type" placeholder="我的视频类型（如：影视解说）" value="${esc(settings.videoType || '')}" />
        <select class="baf-select" id="baf-sort">
          <option value="days-asc">截止时间（近→远）</option>
          <option value="days-desc">截止时间（远→近）</option>
          <option value="match-desc">匹配度（高→低）</option>
        </select>
      </div>
    `;

    // 插入到页面内容区域
    const container = findActivityContainer();
    if (container) {
      // 插入到list-view内部的最前面
      container.insertBefore(toolbar, container.firstChild);
    } else {
      document.body.appendChild(toolbar);
    }

    bindToolbarEvents();
  }

  function getAllCategories() {
    const set = new Set();
    activities.forEach(a => (a.categories || [a.category]).forEach(c => set.add(c)));
    return Array.from(set);
  }

  function findActivityContainer() {
    // B站活动页面结构：.list-view > .list-scroll-box > .list-box > .activity-item
    const listView = document.querySelector('.list-view');
    if (listView) return listView;

    // fallback
    const selectors = [
      '.activity-list',
      '[class*="activity-list"]',
      '[class*="ActivityList"]',
      '.list-container',
      '#app'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function renderActivityList() {
    let listContainer = document.getElementById('baf-activity-list');
    if (!listContainer) {
      listContainer = document.createElement('div');
      listContainer.id = 'baf-activity-list';
      listContainer.className = 'baf-activity-list';
      const toolbar = document.getElementById('baf-toolbar');
      if (toolbar && toolbar.parentNode) {
        // 插入到工具栏之后
        toolbar.parentNode.insertBefore(listContainer, toolbar.nextSibling);
      }
    }

    const list = filterActivities();

    // 更新统计
    document.getElementById('baf-total').textContent = activities.length;
    document.getElementById('baf-active').textContent = activities.filter(a => daysLeft(a.endDate) >= 0).length;
    document.getElementById('baf-ending').textContent = activities.filter(a => { const d = daysLeft(a.endDate); return d >= 0 && d <= 7; }).length;
    document.getElementById('baf-result').textContent = list.length;

    if (list.length === 0) {
      listContainer.innerHTML = '<div class="baf-empty">🔍 没有找到符合条件的活动，试试调整筛选条件</div>';
      return;
    }

    listContainer.innerHTML = list.map(a => {
      const days = daysLeft(a.endDate);
      const match = calcMatch(a, settings.videoType);
      const matchLevel = getMatchLevel(match);
      const isHighMatch = matchLevel === 'high';
      const isEndingSoon = days >= 0 && days <= 7;
      const daysClass = days <= 7 ? 'baf-days-urgent' : days <= 30 ? 'baf-days-normal' : 'baf-days-long';
      const daysText = days < 0 ? '已结束' : days === 0 ? '今天截止' : `剩余${days}天`;

      // 分类图标徽章（取主分类）
      const catIcon = getCategoryIcon(a.category, a.tags);

      const catColors = {
        '综合': '#e6f7ff,#1890ff', '游戏': '#f0f5ff,#2f54eb', '影视': '#fff7e6,#fa8c16',
        '音乐': '#f9f0ff,#722ed1', '知识': '#e6fffb,#13c2c2', '动画': '#fff0f6,#eb2f96',
        '美食': '#fcffe6,#a0d911', '亲子': '#fcffe6,#a0d911', '科技': '#f0f0f0,#595959',
        '鬼畜': '#fff1f0,#f5222d'
      };

      const matchBadge = match === null ? '' : matchLevel === 'high'
        ? `<span class="baf-badge baf-badge-match" style="display:inline-block;">⭐ 高度匹配 ${match}%</span>`
        : matchLevel === 'medium'
          ? `<span class="baf-badge baf-badge-mid" style="display:inline-block;">🔹 中度匹配 ${match}%</span>`
          : `<span class="baf-badge baf-badge-low" style="display:inline-block;">匹配度 ${match}%</span>`;

      return `
        <div class="baf-activity-item ${isHighMatch ? 'baf-high-match' : ''} ${isEndingSoon ? 'baf-ending-soon' : ''}" data-url="${esc(a.url)}" data-id="${Number(a.id) || 0}">
          <div class="baf-cat-badge" style="background:${catIcon.bg};color:${catIcon.color};" title="${esc(catIcon.label)}">${catIcon.icon}</div>
          <div class="baf-activity-item-title">${esc(a.title)}</div>
          <div class="baf-activity-item-cats">
            ${(a.categories || [a.category]).map(c => {
              const colors = (catColors[c] || '#f0f0f0,#595959').split(',');
              return `<span class="baf-cat-tag" style="background:${colors[0]};color:${colors[1]};">${esc(c)}</span>`;
            }).join('')}
          </div>
          <div class="baf-activity-item-tags">
            ${a.tags.slice(0, 4).map(t => `<span class="baf-activity-item-tag">${esc(t)}</span>`).join('')}
          </div>
          <div class="baf-activity-item-info">
            📅 ${formatDate(a.startDate)} - ${formatDate(a.endDate)}<br>
            🏷️ ${esc(a.submitTag)}<br>
            📂 ${esc(a.submitZone)}
          </div>
          <div class="baf-activity-item-reward">💰 ${esc(a.rewardType)}：${esc(a.rewardDesc)}</div>
          ${matchBadge ? `<div style="margin-top:6px;">${matchBadge}</div>` : ''}
          <div class="baf-activity-item-footer">
            <span class="${daysClass}">${daysText}</span>
            ${a.url ? '<span style="color:#fb7299;">点击投稿 →</span>' : ''}
          </div>
        </div>
      `;
    }).join('');

    // 绑定点击事件
    listContainer.querySelectorAll('.baf-activity-item').forEach(item => {
      item.addEventListener('click', () => {
        const url = item.dataset.url;
        if (url) window.open(url, '_blank');
      });
    });
  }

  // ========== 事件绑定 ==========
  function bindToolbarEvents() {
    // 分类筛选
    document.querySelectorAll('#baf-cat-btns .baf-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#baf-cat-btns .baf-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        settings.filters.category = btn.dataset.cat;
        saveSettings();
        renderActivityList();
      });
    });

    // 时间筛选
    document.querySelectorAll('#baf-time-btns .baf-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#baf-time-btns .baf-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        settings.filters.time = btn.dataset.time;
        saveSettings();
        renderActivityList();
      });
    });

    // 奖励筛选
    document.querySelectorAll('#baf-reward-btns .baf-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#baf-reward-btns .baf-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        settings.filters.reward = btn.dataset.reward;
        saveSettings();
        renderActivityList();
      });
    });

    // 搜索（防抖）
    const debouncedRender = debounce(() => renderActivityList());
    document.getElementById('baf-search').addEventListener('input', (e) => {
      settings.filters.search = e.target.value;
      debouncedRender();
    });

    // 视频类型（防抖）
    document.getElementById('baf-video-type').addEventListener('input', (e) => {
      settings.videoType = e.target.value;
      saveSettings();
      debouncedRender();
    });

    // 排序
    document.getElementById('baf-sort').addEventListener('change', (e) => {
      settings.filters.sort = e.target.value;
      saveSettings();
      renderActivityList();
    });
  }

  function saveSettings() {
    chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: settings });
  }

  // ========== 初始化 ==========
  async function init() {
    console.log('[B站活动筛选助手] 正在初始化...');

    // 显示加载状态
    const loading = document.createElement('div');
    loading.id = 'baf-loading';
    loading.className = 'baf-loading';
    loading.innerHTML = '<div class="baf-loading-spinner"></div><div>正在加载活动数据...</div>';
    document.body.appendChild(loading);

    const success = await loadData();

    // 移除加载状态
    if (loading.parentNode) loading.parentNode.removeChild(loading);

    if (!success || activities.length === 0) {
      const err = document.createElement('div');
      err.className = 'baf-loading';
      err.innerHTML = '⚠️ 活动数据加载失败，请刷新页面重试';
      document.body.appendChild(err);
      return;
    }

    console.log(`[B站活动筛选助手] 加载到 ${activities.length} 个活动`);

    // 渲染工具栏和活动列表
    renderToolbar();
    renderActivityList();

    // 隐藏原页面的活动列表（如果存在）
    document.body.classList.add('baf-hide-original');
  }

  // 等待页面加载完成
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    // SPA页面可能需要延迟
    setTimeout(init, 1500);
  }
})();
